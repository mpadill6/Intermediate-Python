# -*- coding: utf-8 -*-
"""
Created on Mon Oct 12 20:30:50 2020

@author: mpadilla
"""

from Helpers import *

inputInt()
inputFloat()
inputString()
inputDate()